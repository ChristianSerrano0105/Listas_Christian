public interface Cola {

}
