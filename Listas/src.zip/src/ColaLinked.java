public class ColaLinked {

}
